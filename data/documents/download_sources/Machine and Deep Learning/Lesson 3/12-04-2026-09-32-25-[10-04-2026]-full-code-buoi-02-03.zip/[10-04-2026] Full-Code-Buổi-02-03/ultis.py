import numpy as np
import matplotlib.pyplot as plt


def visualize_logistic_curve_fitting(sorted_labels, sorted_probs, DECISION_THRESHOLD):

    # Create visualization
    fig, ax = plt.subplots(figsize=(12, 6))

    # Plot actual labels
    class_0_mask = sorted_labels == 0
    class_1_mask = sorted_labels == 1

    ax.scatter(
        np.where(class_0_mask)[0],
        sorted_labels[class_0_mask],
        c="blue",
        alpha=0.7,
        s=50,
        label="Actual Class 0 (≤50K)",
        marker="o",
        edgecolors="black",
    )
    ax.scatter(
        np.where(class_1_mask)[0],
        sorted_labels[class_1_mask],
        c="orange",
        alpha=0.7,
        s=50,
        label="Actual Class 1 (>50K)",
        marker="o",
        edgecolors="black",
    )

    # Plot sigmoid curve
    x_range = np.arange(len(sorted_probs))
    ax.plot(
        x_range,
        sorted_probs,
        color="red",
        linewidth=2.5,
        label="Logistic Curve (Predicted Probabilities)",
        alpha=0.9,
    )

    # Add decision boundary
    ax.axhline(
        y=DECISION_THRESHOLD,
        color="green",
        linestyle="--",
        linewidth=2,
        label=f"Decision Boundary ({DECISION_THRESHOLD})",
        alpha=0.7,
    )

    # Shade prediction regions
    ax.fill_between(
        x_range,
        0,
        DECISION_THRESHOLD,
        alpha=0.1,
        color="blue",
        label="Predicted Class 0 Region",
    )
    ax.fill_between(
        x_range,
        DECISION_THRESHOLD,
        1,
        alpha=0.1,
        color="orange",
        label="Predicted Class 1 Region",
    )

    # Configure plot
    ax.set_xlabel(
        "Sample Index (Sorted by Prediction Probability)",
        fontsize=12,
        fontweight="bold",
    )
    ax.set_ylabel("Probability / Class Label", fontsize=12, fontweight="bold")
    ax.set_title(
        "Logistic Regression: Sigmoid Curve Fitting\n(Training Sample Visualization)",
        fontsize=13,
        fontweight="bold",
    )
    ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
    ax.legend(loc="best", fontsize=9)
    ax.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(
        "logistic_curve_fitting_visualization.png", dpi=150, bbox_inches="tight"
    )
    plt.show()
